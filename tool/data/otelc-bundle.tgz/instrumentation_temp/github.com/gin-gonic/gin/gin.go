// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package server

import (
	"go.opentelemetry.io/otelc/pkg/runtime"
)

var logger = runtime.Logger()
